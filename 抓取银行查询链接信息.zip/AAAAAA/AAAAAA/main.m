//
//  main.m
//  AAAAAA
//
//  Created by RY on 2018/2/12.
//  Copyright © 2018年 RY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
