//
//  GDViewController.h
//  AAAAAA
//
//  Created by ouda on 2018/2/26.
//  Copyright © 2018年 RY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GDViewController : UIViewController

@end
