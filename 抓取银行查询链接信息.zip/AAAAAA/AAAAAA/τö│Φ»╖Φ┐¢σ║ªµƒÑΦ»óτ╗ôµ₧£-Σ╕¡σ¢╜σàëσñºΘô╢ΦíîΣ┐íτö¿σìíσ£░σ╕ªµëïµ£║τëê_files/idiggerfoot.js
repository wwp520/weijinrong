try {
	var gaJsHost = (("https:" == document.location.protocol) ? "https://" : "http://");
	var idgTracker = _alysP.init("idigger", "T-000003-03", "");
	idgTracker._setTrackPath(gaJsHost + 'traffic.cebbank.com/main/adftrack');
	idgTracker._setLinkClick(true);
	idgTracker._trackPoint();
} catch (err) { }
