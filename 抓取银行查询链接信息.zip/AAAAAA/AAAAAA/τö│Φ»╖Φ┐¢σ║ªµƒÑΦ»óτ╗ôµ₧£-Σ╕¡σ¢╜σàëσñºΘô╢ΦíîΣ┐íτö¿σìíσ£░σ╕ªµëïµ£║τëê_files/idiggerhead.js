
var gaJsHost = (("https:" == document.location.protocol) ? "https://" : "http://");
document.write(unescape("%3Cscript src='" + gaJsHost + "traffic.cebbank.com/bnnr/idigger.js' type='text/javascript'%3E%3C/script%3E"));
document.write(unescape("%3Cscript src='/js/cebmms/jweixin-1.0.0.js' type='text/javascript'%3E%3C/script%3E"));
