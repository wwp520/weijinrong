//
//  HouseLoanController.h
//  chengzizhifu
//
//  Created by RY on 16/5/16.
//  Copyright © 2016年 ZYH. All rights reserved.
//

#import "BaseViewController.h"

@interface HouseLoanController : BaseViewController

@end
