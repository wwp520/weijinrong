//
//  OwnerLandController.h
//  chengzizhifu
//
//  Created by RY on 16/5/17.
//  Copyright © 2016年 ZYH. All rights reserved.
//

#import "BaseViewController.h"

@interface OwnerLandController : BaseViewController

@property (nonatomic, copy) NSString *type; //类型 3 代表优e通

@end
