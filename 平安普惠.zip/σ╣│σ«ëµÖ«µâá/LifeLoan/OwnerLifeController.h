//
//  OwnerLifeController.h
//  chengzizhifu
//
//  Created by RY on 16/5/18.
//  Copyright © 2016年 ZYH. All rights reserved.
//

#import "BaseViewController.h"

@interface OwnerLifeController : BaseViewController

@end
